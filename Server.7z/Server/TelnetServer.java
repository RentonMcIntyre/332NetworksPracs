/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author SinghAn
 */
public class TelnetServer {
    private static Socket tester=new Socket();
    private static int Question=-1;
    /**
     * @param args the command line arguments
     */
    private static ArrayList<testNode> questions=new ArrayList<>();

    public static class testNode
    {
    private String question;
    private ArrayList<String> answers=new ArrayList<>();
    };

    public static void main(String[] args) throws IOException
    {

        int port=55555;
        try

        {
            ServerSocket myServer=new ServerSocket(port);
            constructTest();

          while (true)
            {
                Socket client=myServer.accept();
                new TelThread(client).start();
                //list.add(0, client);
                tester=client;
                System.out.println("A new person has joined.");
                announce("Welcome User to the Telnet Tester");
                ///id++;
                ins();

            }
        }
         catch(IOException e)
              {
          System.out.println(e.getMessage());
           }

    }


   synchronized static void announce(String msg) throws IOException
    {
        Socket s;
        PrintWriter p;

            p=new PrintWriter(tester.getOutputStream(),true);
            p.println(msg);
    }

   synchronized static int message() throws IOException
   {
        Socket s;
        PrintWriter p;

        Random number=new Random();
        int n=number.nextInt(questions.size());


            p=new PrintWriter(tester.getOutputStream(),true);
            p.println(" ");
            p.println(questions.get(n).question);
            char a='A';
            for (int i=0;i<questions.get(n).answers.size();i++)
            {
                p.println(a+":"+questions.get(n).answers.get(i).substring(1));
                a++;
            }
            p.println(" ");

            p.println("Select an option");

            return n;
   }
   synchronized static void leave(Socket client) throws IOException
   {
        PrintWriter p;
            p=new PrintWriter(tester.getOutputStream(),true);
            p.println("Tester  has left");

        tester=null;
   }
      synchronized static void giveScore(TelThread user) throws IOException
   {
        PrintWriter p;
            p=new PrintWriter(tester.getOutputStream(),true);
            p.println("Your score is: "+user.score);


   }
      synchronized static void ins() throws IOException
      {
        Socket s;
        PrintWriter p;
            p=new PrintWriter(tester.getOutputStream(),true);
            p.println(" ");
            p.println("Commands (To type in)");
            p.println(" ");
            p.println("Score- See your score");
            p.println(" ");
            p.println("Next Question - go to the next question of the test");
            p.println(" ");
            p.println("bye- leave the test");
            p.println(" ");

      }
   synchronized static boolean checkAnswer(String ans)
   {

       testNode tmp=new testNode();
       tmp.question=questions.get(Question).question;
       tmp.answers=questions.get(Question).answers;
       int actualAns=-1,answer=-1;
       switch (ans)
       {
           case "A":answer=0;break;
           case "B":answer=1;break;
           case "C":answer=2;break;
           case "D":answer=3;break;
           case "E":answer=4;
       };
       boolean answered=false;

       for(int i=0;i<tmp.answers.size()&& answered==false;i++)
       {
           if(tmp.answers.get(i).startsWith("+") && answered==false)
           {
                              actualAns=i;
           }
           else if(tmp.answers.get(i).startsWith("+More")&& answered==false)
               {
                   actualAns=i;
                   answered=true;
               }
           else if(tmp.answers.get(i).startsWith("+None")&& answered==false)
               {
                   actualAns=i;
                   answered=true;
               }


       }


       return (actualAns==answer);
   }

   synchronized static void correctAns(TelThread user) throws IOException
   {
               Socket s;
        PrintWriter p;

            p=new PrintWriter(tester.getOutputStream(),true);
            p.println("Congratulations. You got it right!");
            user.score++;
            p.println(" ");
   }

   synchronized static void wrongAns(int a) throws IOException
   {
        Socket s;
        PrintWriter p;
        String cAns="";
        for (int i=0;i<questions.get(a).answers.size();i++)
        {
            if (questions.get(a).answers.get(i).startsWith("+"))
                {

                  for (int k=0;k<questions.get(a).answers.size();k++)
                  {
                      if (questions.get(a).answers.get(k).equals("+More than one of the above"))
                      {
                          cAns=questions.get(a).answers.get(k);
                      }
                      if (questions.get(a).answers.get(k).equals("+None of the above"))
                      {
                          cAns=questions.get(a).answers.get(k);
                      }
                  }

               cAns=questions.get(a).answers.get(i);
                }
        }

            p=new PrintWriter(tester.getOutputStream(),true);
            p.println("The correct answer is:"+ cAns.substring(1));
            p.println(" ");
            p.println("Enter input");

   }

    private static void constructTest() throws IOException
   {



       FileReader fr=new FileReader("quiz.txt");
       BufferedReader textReader=new BufferedReader(fr);

       String sline;
       int q=0;
       while ((sline=textReader.readLine())!=null)
        {
            textReader.mark(1000);
            if (sline.charAt(0)=='?')
            {
                //textReader.mark(100);
                testNode tmp=new testNode();
                tmp.question=sline;
                //textReader.skip(0);
                while ((sline=textReader.readLine())!=null&&(sline.charAt(0)!='?'))
                {

                    tmp.answers.add(0,sline);
                }
                textReader.reset();
                int onlyRight=0,onlyWrong=0;
                for(int i=0;i<tmp.answers.size();i++)
                {
                   if (tmp.answers.get(i).startsWith("+")==true)
                   {
                       onlyRight++;
                   } else if (tmp.answers.get(i).startsWith("-")==true)
                    {
                        onlyWrong++;
                    }
                }
                if ((onlyRight>1) && (onlyWrong==0))
                {
                    tmp.answers.add("+More than one of the above");
                }

                if ((onlyRight==0) && (onlyWrong>1))
                {
                    tmp.answers.add("+None of the above");
                }
                questions.add(0,tmp);
            }

        }

       }
   synchronized static public void setQ(int a)
    {
        Question=a;
    }
   synchronized static public int getQ()
    {
        return Question;
    }
}
